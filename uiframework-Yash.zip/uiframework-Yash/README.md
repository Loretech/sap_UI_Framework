# uiframework

# step-1 Install Node modules
# step-2 For chart page - give routes to charts in the URL (For exp - localhost:4200/charts)